token = '5759898198:AAHnPfg8y2jesjHLBl3H00n_tHAx8UbZglU'
bot_name = '@A1_IT_bot'

print('starting up أنيا')
