# computer skills

# definitions

computer = 'Computer : an electronic device that has the ability to receive data, modify it, process it and convert it to valuable information,' \
           'then store it in internal or external storage media. 🗿 \n Computers vary in their speed and specifications. \n' \
           'Computers operate with an operating system and without it computers are useless.'

hardware = 'Hardware : it is the set of physical parts of a computer system, that make up the computer.\n' \
           'Such as the screen, keyboard, data storage media (such as the hard disk), \n' \
           'and the system unit 🗿 (graphics card, sound card, memory , motherboard, and other chips etc.). \n' \
           'that is all physical things that can be touched. Conversely, software and data are not included in the description of computer hardware.'
software = 'software : it is a set of machine-readable instructions that direct a computer\'s processor to perform specific operations. 🗿 \n' \
           'a set of software and computer hardware make up a usable computer system.'

CPU = 'CPU : the processor is a small silicon chip that contains complex electronic circuits. 🗿 '
arithmetic_logical_unit = 'arithmetic logical unit : it is where arithmetic and logical operations are processed.'
control_unit = 'control unit : it is considered the brain of the computer, it can issue commands to all computer departments and coordinate among them to perform the required functions between them. '

storage_devices = 'storage devices : it allows the user to store data before or after processing it to get it back later.'
hard_disk = 'hard disk : it is a magnetic-coated metal disc placed inside an airtight and sealed container. Information is stored in it permanently with the ability to delete or re-store it.'
floppy_disk = 'floppy disk : it consists of cylinders made of plastic material and coated with brown magnetic material and is considered a mobile store, but its storage capacity is limited.'

