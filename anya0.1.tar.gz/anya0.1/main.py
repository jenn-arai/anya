import random

from telegram.ext import *
import keys , skills


def start_command(update, context):
    update.message.reply_text(
        ' هلو اسمي انيا, انيا بوتة الشعبة A قسم نظم المعلومات' + '\n' + 'شعبة A حاليا مرحلة اولى بس انيا راح تبقى بوتتهم حتى من يصعدون لباقي المراحل > _ <')


def help_command(update, context):
    update.message.reply_text('انيا بعدهي قيد التطوير , _ ,')


def send_pic_command(update, context):
    bot.send_photo(update.message.chat.id, photo=open('schedule.png', 'rb'))
    update.message.reply_text('ياا انيا صارت تعرف ترسل جدول انيا سوبر فرحانه > _ <')
    # update.message.answer_photo('https://media.discordapp.net/attachments/921287193828425778/1050734993850245120/screenshot_2022-12-09-14-07-14-43_c37d74246d9c81aa0bb824b57eaf7062.jpg')


def handle_response(text: str):  # important
    if 'آنيا' in text or keys.bot_name in text:
        if 'هلو' in text:
            return 'هلو uwu'
        if 'شلونج؟' in text or 'شلونج' in text:
            return 'آنيا زينة'

        if 'جدول' in text:  # star
            return 'ياا آنيا صارت تعرف ترسل جدول آنيا سوبر فرحانه > _ <'
        if 'بيت' in text and 'وين' in text:
            return random.choice([' حاليا آنيا عايشة بلابتوب 🥲 آنيا تريد سيرفر.. ', '🥲 آنيا ما تكول انيا تخاف تنخطف',
                                  '😱😱😱 انيا تلوذ بلفرار 🏃🏼 ', ' حاليا آنيا عايشة بلابتوب 🥲 آنيا تريد سيرفر.. ',
                                  'حاليا آنيا عايشة بلابتوب 🥲 آنيا تريد سيرفر.. '])
        if 'لا' in text and 'ضوجين' in text:
            return random.choice(['محد يهتم بمشاعر آنيا', 'آنيا تريد تموت..', '🥲', 'شكرا آنيا زينة', 'آنيا اسوء بوت..'])
        if 'لا' in text and 'زعلين' in text:
            return random.choice(
                ['محد يهتم بمشاعر آنيا', 'آنيا مو قصدهة تزعل بس انيا زعلانة', '🥲', 'شكرا آنيا زينة', 'آنيا اسوء بوت..'])
        if 'تردين' in text:
            return random.choice(['يي اريد', 'اوكي آنيا تقبل تاخذ', 'يي نطيني', 'ما', 'شكرا آنيا متريد'])
        if 'تريدين' in text:
            return random.choice(['يي اريد', 'اوكي آنيا تقبل تاخذ', 'يي نطيني', 'ما', 'شكرا آنيا متريد'])
        if 'مال' in text and 'من' in text and 'انتي' in text:
            return 'آنيا مالت حوراء > _ < '
        if 'سواج' in text and 'من' in text:
            return '!diotic Jenn#6790'
        if 'سويج' in text and 'من' in text:
            return '!diotic Jenn#6790'
        if 'طلعي' in text:
            return random.choice(['لا فدوة لا حبابيين لا طردون آنيا', 'ب-بس آنيا شنو سوت؟🥲🥲'])
        if 'تحبين' in text:
            return random.choice(['يب', 'كلش هواي', 'شوي', 'لا', 'ما اعرف'])
        if 'ولي' in text:
            return 'اسفة...'
        if 'سكتي' in text:
            return 'آنيا سكتت'
        if 'مسوي' in text and 'دايت':
            return random.choice(['هية آنيا بوت وين شايفة الاكل اصلا 🥲🥲 '])
        if 'خطف' in text and 'خل':
            return random.choice(['تمام آنيا تحب الخطف'])
        if 'قتل' in text:
            return random.choice(['آنيا ماتحب القتل'])
        if 'وجع' in text:
            return random.choice(['🥲🥲'])
        if 'نجب' in text:
            return random.choice(['🥲🥲 آنيا نجبت'])
        if 'تعالي' in text or 'تعاي' in text:
            return random.choice(['آنيا اجت'])
        if 'طردو' in text or 'طردي' in text:
            return random.choice(['الطرد شي مو حلو'])
        if 'طلعو' in text or 'طلعي' in text:
            return random.choice(['Anya left the chat '])
        if 'ليش' in text and 'ما' in text and 'ترد' in text:
            return random.choice(['آنيا ما عدهة رد', 'آنيا اسفة', ' آنيا بعدهي ما تعرف شنو تكول..'])
        if 'ردي' in text:
            return random.choice(['آنيا ما عدهة رد', 'آنيا اسفة', ' آنيا بعدهي ما تعرف شنو تكول..'])
        if 'منو' in text or ' منو انتي' in text or 'انتي منو' in text or 'انت منو' in text or 'منو انت' in text:
            return ' هلو اسمي آنيا, آنيا بوتة الشعبة A قسم نظم المعلومات' + '\n' + 'شعبة A حاليا مرحلة اولى بس انيا راح تبقى بوتتهم حتى من يصعدون لباقي المراحل > _ <'
        if 'صباح' in text:
            return random.choice(['آنيا ما تحب الصبح', 'صباح الخير', 'صباحكم', 'صباح النور'])
        if 'مساء' in text:
            return random.choice(['مسائكم', 'مساء الخير', 'مساء النور'])
        if 'ملزمة' in text.replace('ه', 'ة') and 'برمجة' in text.replace('ه', 'ة'):
            return '❤❤'
        # تعاريف
        if 'تعريف' in text or 'عرفي' in text or 'شنو' in text:
            if 'حاسوب' in text or 'كمبيوتر' in text or 'computer' in text:
                return skills.computer
            if 'اجهزة الكمبيوتر' in text.replace('ه', 'ة') or 'هاردوير' in text or 'hardware' in text:
                return skills.hardware
            if 'برامج' in text or 'سوفتوير' in text or 'software' in text:
                return skills.software
            if 'معالج' in text or 'سي بي يو' in text or 'cpu' in text:
                return skills.CPU
            if 'وحدة منطقية' in text.replace('ه', 'ة') or 'ارذمتك لوجكل يونت' in text or 'arithmetic logical unit' in text:
                return skills.arithmetic_logical_unit
            if 'وحدة التحكم' in text.replace('ه', 'ة') or 'كنترول يونت' in text or 'control unit' in text:
                return skills.control_unit
            if 'اجهزة التخزين' in text.replace('ه', 'ة') or 'ستورج' in text or 'storage' in text:
                return skills.storage_devices
            if 'فرص صلب' in text or 'هارد دسك' in text or 'hard disk' in text:
                return skills.hard_disk
            if 'فرص مرن' in text or 'فلوبي دسك' in text or 'floppy disk' in text:
                return skills.floppy_disk






        if text.strip() == 'آنيا':
            return 'نعم'
        if 'آنيا' in text:
            # 'آنيا ما اتعرف جواب لهل كلام', 'آنيا ما تعرف هواي اشيائات علموها لآنيا بليز', 'آنيا ما تدري بس آنيا تريد تتعلم',
            return random.choice(['🤷'])


def handle_message(update, context):
    message_type = update.message.chat.type
    text = str(update.message.text).lower()

    print(f'User ({update.message.chat.id}) says: "{text}" in: "{message_type}"')

    if message_type == 'supergroup':

        if keys.bot_name in text or 'آنيا' in text:
            new_text = text
            response = handle_response(new_text)
        if 'جدول' in new_text and 'آنيا' in new_text:
            bot.send_photo(update.message.chat.id, photo=open('schedule.png', 'rb'))

        if 'ملزمة' in new_text.replace('ه', 'ة') and 'آنيا' in new_text and 'برمجة' in new_text.replace('ه', 'ة'):
            bot.send_document(update.message.chat.id, document=open('books/Computer ProgrammingI.pdf', 'rb'))

    else:
        response = handle_response(text)

    update.message.reply_text(response)


def error(update, context):
    print(f'Update: {update}, caused error: {context.error}')


if __name__ == '__main__':
    bot = ExtBot(keys.token)
    updater = Updater(keys.token, use_context=True)
    dp = updater.dispatcher

    # commands
    dp.add_handler(CommandHandler('start', start_command))
    dp.add_handler(CommandHandler('help', help_command))
    dp.add_handler(CommandHandler('schedule', send_pic_command))

    # messages
    dp.add_handler(MessageHandler(Filters.text, handle_message))

    # error
    dp.add_error_handler(error)

    # run bot
    updater.start_polling(1.0)
    updater.idle()
